package facade.provider;

public enum Operations {
    BUY, SELL
}
