package proxy;

public interface StorageRequest {
    void doRequest(Request request);
}
