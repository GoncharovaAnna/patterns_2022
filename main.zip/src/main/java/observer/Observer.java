package observer;

public interface Observer {
    void Update(Coordinates coordinates, int taxiId);
}
