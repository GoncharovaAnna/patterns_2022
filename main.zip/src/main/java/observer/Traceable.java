package observer;

public interface Traceable {
    Coordinates GetCoordinates();
}
