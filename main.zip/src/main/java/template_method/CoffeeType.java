package template_method;

public enum CoffeeType {
    TYPE1, TYPE2
}
